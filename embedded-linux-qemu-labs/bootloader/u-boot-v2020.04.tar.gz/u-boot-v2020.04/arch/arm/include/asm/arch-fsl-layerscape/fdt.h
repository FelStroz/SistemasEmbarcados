/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright 2015 Freescale Semiconductor
 */

#ifndef _ASM_ARMV8_FSL_LAYERSCAPE_FDT_H_
#define _ASM_ARMV8_FSL_LAYERSCAPE_FDT_H_

void fdt_fixup_board_enet(void *fdt);
#endif	/* _ASM_ARMV8_FSL_LAYERSCAPE_FDT_H_ */
